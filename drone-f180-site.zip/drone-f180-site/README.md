# Drone F180 4K GPS – Static Site (GitHub Pages)
Bilingual static product site (IT default).

## Deploy
1. Create a new GitHub repo and upload everything (keep `.nojekyll`).
2. Settings → Pages → Deploy from branch: `main`, Folder `/ (root)`.
3. Open: https://<user>.github.io/<repo>/

## Replace photos
- Put your images into `assets/photos/` and keep names `photo1.jpg`..`photo6.jpg` (or edit HTML).
