document.querySelectorAll('.gallery img').forEach(img=>{
  img.addEventListener('click',()=>{
    const lb=document.querySelector('.lightbox'); const big=lb.querySelector('img');
    big.src=img.dataset.full||img.src; lb.classList.add('active');
  });
});
document.querySelectorAll('.lightbox,.close').forEach(el=>el.addEventListener('click',e=>{
  if(e.target.classList.contains('lightbox')||e.target.classList.contains('close')){
    document.querySelector('.lightbox').classList.remove('active');
  }
}));